         // MULTILEVEL  INHERITANCE 

#include <iostream>
using namespace std;
class Student{
    protected:
    int roll;
};
class Test:protected Student{
    protected:
    int t1;
    int t2;
};
class Result:public Test{
    int score;
    public:
    void getdata(){
        cout<<"\nEnter roll and test score: ";
        cin>>roll>>t1>>t2;
        cout<<"\n Enter sports score: ";
        cin>>score;
    }
    void getresult(){
        cout<<"Roll no: "<<roll<<endl;
        cout<<"Test scores: "<<t1<<" "<<t2<<endl;
        cout<<"Sports score: "<<score<<endl;
        cout<<"Final score: "<<t1+t2+score<<endl;
    }
};
int main(){
    Result r;
    r.getdata();
    r.getresult();
}

         // MULTIPLE INHERITANCE CLASS
#include <iostream>
using namespace std;
class Academic{
    protected:
    int ascore;
    public:
    void  getascore(){
        cout<<"Enter ascore: ";
        cin>>ascore;
    }
};
class Sports{
    protected:
    int sscore;
    public:
    void getsscore(){
        cout<<"Enter sscore: ";
        cin>>sscore;
    }
};
class Result:public Academic,public Sports{
    public:
    void showresult(){
        getascore();
        getsscore();
        cout<<"\n Final score: "<<ascore+sscore<<endl;
    }
};
int main(){
    Result r;
    r.showresult();
}


// MULTIPLE INHERITANCE CLASS AMBIGUITY PROBLEM

#include <iostream>
using namespace std;
class Academic{
    protected:
    int score;
    public:
    void  getscore(){
        cout<<"Enter ascore: ";
        cin>>score;
    }
};
class Sports{
    protected:
    int score;
    public:
    void getscore(){
        cout<<"Enter sscore: ";
        cin>>score;
    }
};
class Result:public Academic,public Sports{
    public:
    void showresult(){
        
        // getsscore();
        cout<<"\n Final score: "<<Academic::score+Sports::score<<endl;
    }
};
int main(){
    Result r;
    r.Academic::getscore();
    r.Sports::getscore();
    r.showresult();
}


// Diamond problem Hybrid INHERITANCE CLASS
#include <iostream>
using namespace std;
class A{
    protected:
    int x;
};
class B:virtual public A{
    protected:
    int y;
};
class C:virtual public A{
    protected:
    int z;
};
class D :public B,public C{
    public:
    int sum;
    void getdata(){
        cout<<"Enter x,y and z: ";
        cin>>x>>y>>z;
    }
    void showdata(){
        cout<<"sum: "<<x+y+z<<endl;
    }
};
int main(){
    D d;
    d.getdata();
    d.showdata();
}
