      INHERITANCE  

// #include <iostream>
// using namespace std;
// class Person{
//     string name;
//     public:
//     void getPer(){
//         cout<<"Enter name: ";
//         cin>>name;
//     }
//     void showper(){
//         cout<<"Name: "<<name<<endl;
//     }
// };
// class Student:public Person{
//     int roll;
//     public:
//     void getst(){
//         cout<<"Enter roll no: ";
//         cin>>roll;
//     }
//     void shows(){
//         cout<<"roll no: "<<roll<<endl;
//     }
// };
// int main() {
//     Student ob;
//     ob.getPer();
//     ob.getst();
//     ob.showper();
//     ob.shows();
//     return 0;
// }


    INHERITANCE USING PRIVATE ACCESS 
// #include <iostream>
// using namespace std;
// class Person{
//     string name;
//     public:
//     void getPer(){
//         cout<<"Enter name: ";
//         cin>>name;
//     }
//     void showper(){
//         cout<<"Name: "<<name<<endl;
//     }
// };
// class Student:private Person{
//     int roll;
//     public:
//     void getst(){
//         getPer();
//         cout<<"Enter roll no: ";
//         cin>>roll;
        
//     }
//     void shows(){
//         showper();
//         cout<<"roll no: "<<roll<<endl;
//     }
// };
// int main() {
//     Student ob;
//     // ob.getPer();
//     ob.getst();
//     // ob.showper();
//     ob.shows();
//     return 0;
// }
